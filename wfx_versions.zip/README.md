# Versions WFX Plugin (Total Commander)

`Versions` is a Total Commander file system plugin that checks program/version strings on web pages and shows the current status directly in TC.

This repository contains an updated FPC/Lazarus-compatible codebase with reliability, parsing, and UX improvements.

## Key Features

- Checks version entries from `.list` files.
- Checks downloadable files through `Last-Modified` without downloading their
  body, with a streaming SHA-256 fallback when no usable server timestamp exists.
- Exposes numeric WFX custom columns for the visible list position and physical
  source line.
- Shows `#`, `##`, and `###` list comments as non-executable virtual rows with
  a comment icon and three visual indentation levels.
- Supports HTTPS and modern HTTP behavior.
- Keeps list entry order in output.
- Shows localized status labels (`NEW`, `UNCHANGED`, `ERROR`, etc.) based on selected language file.
- Works with Unicode and 64-bit builds.

## Recently Added / Improved

- Parallel page fetching with configurable worker count.
  - New INI key: `MaxParallelRequests` (default `8`).
  - Results are processed and shown after all list entries are finished.
  - Return values are evaluated per entry.
- Configurable connection timeout.
  - New INI key: `ConnectTimeout` in milliseconds (default `5000`).
  - Send and receive timeouts are each 10 seconds. These are per-phase
    WinHTTP timeouts, not an overall deadline for the entry; transient failures
    can still trigger up to three attempts. Windows timing and cleanup add
    overhead (the stalled-header regression takes about 36 seconds total).
  - Cancellation closes active WinHTTP request handles, stops retries and new
    work, and is checked while waiting for Chrome serialization. An initial
    cancellation no longer starts the fetch batch.
- Windows-native HTTPS stack.
  - HTTP transport now uses WinHTTP instead of OpenSSL sockets.
  - Removes OpenSSL runtime DLL dependency for HTTPS in this plugin.
- Optional request logging.
  - New INI keys: `RequestLog` and `RequestLogFile`.
  - Thread-safe logging with timestamp, URL, status, and error code.
- Better handling of `.list` files.
  - Empty lines are ignored.
  - Lines starting with `;` are treated as comments and ignored.
  - `.list` files may be organized in arbitrary nested subfolders below the plugin's `Lists` directory; that hierarchy is reflected in `Network Neighborhood > Versions`.
  - `.list` files beside the plugin DLL remain visible and behave exactly as before.
  - Outside the `Lists` tree, other plugin subfolders are ignored. Within `Lists`, only folders containing at least one `.list` file directly or recursively are displayed.
  - The displayed `.list` file size shows the number of valid entries (non-empty, non-comment), including lists in subfolders.
- Parser improvements for markers.
  - Marker matching works across line breaks.
  - Version text is extracted with original casing preserved.
  - Found version text is limited to `64` UTF-8 bytes.
- Progress display improvements.
  - Total Commander progress now includes current count and the entry name (first field in `.list`).
- Improved request robustness.
  - Firefox-like User-Agent and browser-like headers.
  - Retry handling for transient HTTP/IO errors.
- Automatic protection-page handling.
  - Detects Cloudflare challenge/block pages, Anubis challenges, and simple JavaScript-cookie challenges from HTTP headers and HTML signatures.
  - Transparently decompresses gzip/deflate HTTP responses before protection detection and marker parsing.
  - Does not mistake Cloudflare's JavaScript detector embedded in an otherwise complete page for an active challenge.
  - Keeps WinHTTP as the normal transport and starts Chrome only for a detected protection page.
  - Uses a Chrome-version-matched normal browser User-Agent instead of the detectable HeadlessChrome identifier.
  - If an interactive Cloudflare or Anubis challenge remains, temporarily starts a normal Chrome window off-screen and reads its final DOM through a localhost DevTools connection.
  - Closes that Chrome instance via DevTools after success, timeout, or cancellation; a dedicated Windows job object removes remaining child processes as a fallback.
  - Bounds each synchronous DevTools WebSocket read to five seconds, so a stalled DOM response cannot bypass the configured Chrome timeout.
  - Uses a separate persistent Chrome profile so challenge cookies can be reused.
  - Serializes Chrome calls while regular WinHTTP requests remain parallel.
- Localized error output.
  - Errors are shown with localized error extension (language-dependent), while keeping technical details in logs.

## `.list` Format

A standard entry uses six fields:

`Name|URL|StartMarker|LeftMarker|RightMarker|CurrentVersion`

A search-only entry uses three fields:

`Name|URL|Parameters`

A downloadable-file entry also uses six fields, but leaves the first two
search markers empty:

`Name|URL|||ComparisonValue|DisplayDate`

Example before the first check:

`AFU Rufzeichenliste|https://example.invalid/file-page.html|||checksumme|01.01.2024`

The plugin recognizes this as file mode because `StartMarker` and `LeftMarker`
are empty. `ComparisonValue` is maintained automatically:

- `last-modified:2026-10-23T06:44:00Z` means the final server response supplied
  a valid `Last-Modified` header. The full UTC timestamp is compared, while
  `DisplayDate` contains the readable local list value such as `23.10.2026`.
- `sha256:<64 hexadecimal characters>` means no usable `Last-Modified` was
  available. The file is streamed through SHA-256 without keeping the complete
  file in memory. `DisplayDate` is the date on which that exact checksum was
  first observed.

For virtual result entries in Total Commander, the standard **Date** column now
uses the same file information: a `Last-Modified` entry shows the exact server
timestamp converted to local time, while a SHA-256 entry shows its stored first
observation date at local midnight. Pattern-based version checks, comments,
and result entries without a valid file date leave the Date column empty.

File-check sequence:

1. Existing redirects are followed automatically.
2. Unless the entry is already in SHA-256 mode, the plugin first sends `HEAD`.
3. If necessary, it retries the header probe with `GET` and
   `Range: bytes=0-0`; the response body is not downloaded.
4. A valid `Last-Modified` is stored and compared without downloading the file.
5. Without `Last-Modified`, the complete file is downloaded once and hashed.
6. A stored `sha256:` value keeps the entry in SHA-256 mode. To retry
   `Last-Modified`, clear only `ComparisonValue` while retaining all pipe
   separators, for example `Name|URL||||23.10.2026`.

The checksum/timestamp and display date are changed only after a successful,
complete check. Cancellation, timeout, HTTP errors, or an HTML response where a
file was expected leave the list entry unchanged. When switching comparison
methods without a comparable previous value, the new value becomes a baseline
and is shown as unchanged. An existing date can be used for a one-time
date-only comparison when initializing or returning to `Last-Modified` mode.

Notes:

- Empty lines are ignored.
- Lines whose first non-space character is `;` are internal comments and remain
  hidden.
- Lines whose first non-space characters are `#`, `##`, or `###` are visible
  comments. The marker and whitespace immediately following it are omitted in
  the virtual name: `# Text` is shown as `Text`, `## Text` as `    Text`, and
  `### Text` as `        Text`. A marker without text is shown as `(comment)`.
  They never trigger a request, URL, editor, download, or other execution.
- Characters that are invalid in virtual Windows filenames are replaced only in
  the displayed comment name. The original `.list` line is saved unchanged.
- If two visible rows would have the same name, a visible comment receives a
  source-line suffix such as `[line 12]` to keep its virtual path unique.
- Marker text can span multiple lines in downloaded HTML source.
- 3-field entries are shown as `.SEARCH` (localized) and are not fetched for version parsing.
- Lists can be placed beside the plugin DLL or recursively below `Lists`, for example `Lists\Utilities\NirSoft.list`. The same folders appear below `Network Neighborhood > Versions`; other plugin subfolders are not scanned.

## Editing A Single Result

Press plain **F4** on a virtual result entry to open the native entry editor.
The same editor is available through the result's **Properties** command.
The compact editor separates the original entry into its pipe-delimited fields,
with labels for name, URL, markers, stored version (or comparison value/date).
Short variable-based entries retain a combined Pattern / variable field.
A read-only preview displays the complete reconstructed entry. Each referenced
variable's active definition is editable in a separate single-line field without
visible scrollbars. Multiple variables receive one field each. Shared definitions
affect other entries using that definition. Keep one definition per displayed
variable row; adding/deleting rows is not supported.

Save validates the expanded entry, checks for concurrent list changes, stages
and verifies a temporary file, then replaces the list. Only edited source rows
are replaced; all other bytes, line endings and the BOM remain unchanged.
The editor is centered on the Total Commander main window, constrained to the
monitor work area. Saving does not reload the panel or request any URLs. The
displayed results remain unchanged until F3 (single entry) or Ctrl+R (full list).
The internal source text is synchronized without checking versions, so another
F4 or F3 uses the newly saved entry and variable definitions.

The **Test** button queries the currently entered fields and variable values
without saving them. A single-line, read-only **Test result** field in the same window
shows the normal version/file-check result, HTTP status or parsing error. The
two-line **Raw output** field below it shows the original matched HTML/text
from the start marker through the end marker, both included, preserving case
and line breaks. Without a complete match it reports that no complete range
was found. File checks show the final HTTP response headers (or the transport
error when no server response exists), not the downloaded file body. The same
request is used; showing headers does not trigger an extra download.
The
request runs on a worker thread with the usual WinHTTP/Chrome fallback behavior.
Test, Save and closing the dialog are disabled until the request completes or
times out. The test uses isolated response data: no list file, stored baseline,
or panel result is changed. Three-field search entries retain their SEARCH
behavior and do not perform a version request.
The list loader, normal checks and F4 Test share the same Unicode decoding.
UTF-8 (with/without BOM) and UTF-16 LE/BE with BOM are supported. Without a BOM,
valid UTF-8 is preferred; otherwise the current Windows ANSI codepage is used.
For legacy files whose codepage differs from Windows, put a leading comment
before the first entry (the same declaration works in the INI):

```text
; encoding=windows-1251
```

For example, use `windows-1252` for Western legacy files or `windows-1251` for
Cyrillic legacy files. No language/codepage is guessed from the visible text.
A BOM takes precedence. New lists created by Add Search remain CP1252.
CP1252 cannot represent Cyrillic: use an explicitly Unicode list for those entries.

HTTP text is decoded from its BOM, Content-Type charset or HTML charset metadata
before matching. Otherwise valid UTF-8/system ANSI is used. Case-insensitive
matching handles Unicode, including Cyrillic; raw output retains the original
case and line breaks. Plugin results and F4 Test use the same normalized text.

Both INI and list updates preserve the original encoding, BOM, line endings,
comments and unchanged source bytes. Files are staged and validated before
replacement; unrepresentable changes and concurrent edits are rejected rather
than saved as question marks. Reading/testing does not rewrite the INI. ASCII
INI keys retain their original names/defaults; inline `;`/`#` comments are supported
without stripping quoted text, URL fragments or tabs inside values.
Cancel writes nothing. A source-row mismatch requires refreshing the list.

F3/F4 are recognized via a thread-local TC message hook. On TC 9+ the hook checks
the active list and path controls, suppresses the original key, and dispatches
the selected item through TC's Properties command. The plugin handles that
command internally, so TC does not start a Lister/download for these actions.
No TC shortcuts or configuration are changed. Ordinary
copy requests remain blocked for virtual result entries. TC's mouse-operated
Edit button is not treated as a plain F4 key; use Properties instead.
Listing paths and Properties callback paths share a canonical metadata key,
including when TC omits the leading backslash. This keeps F4/F3 source-row
lookups consistent with the displayed results.

**Shift+F4** inside an opened list opens the complete physical `.list` in
Notepad, like the existing list Properties action, instead of opening the
single-entry editor or TC's new-file dialog.

**F3** on a version/file-check result repeats only that entry's request and
updates its displayed result and timestamp. Other result rows retain their
current display and are not queried again. A changed comparison baseline is
saved through the single-row patch writer, preserving variable references.
The following TC panel refresh replays the in-memory result list without a
full network update. This is a result-panel refresh, not a downloaded document
opened in a separate Lister window. Shared URLs are requested once for the
selected entry; other rows using that URL are not re-evaluated.

## List Variables

Define list-local text substitutions in hidden comment lines, for example:

```text
; $github=anchorId":"release|-|"
Adalm Pluto FW|https://github.com/analogdevicesinc/plutosdr-fw/releases|$github|v0.39
```

Everything after the first `=` is copied verbatim, including spaces, quotes,
`|`, `;`, and `#`. Names use `[A-Za-z_][A-Za-z0-9_]*` and are case-sensitive.
Definitions apply to following entries; redefinitions replace previous values.
Multiple variables and empty values are supported. Expansion is single-pass,
not recursive, and happens before splitting fields. There is no dollar escape:
matching variable references in URLs or patterns are expanded too. Unknown
variables report `VARIABLE - undefined: $name` without a network request.
Definitions do not carry over to other lists. Saving updated versions or file
comparison values preserves the original variable references and definitions.

## Custom Columns And Original Order

The WFX plugin exports three content fields:

- `List position` is the consecutive visible position (`1, 2, 3, ...`). Hidden
  empty lines and `;` comments do not consume a position. Sorting ascending by
  this field restores the visible order of the `.list`, including all three
  comment levels.
- `Source line` is the physical one-based line number in the `.list`. It can
  contain gaps because empty lines and `;` comments remain hidden.
- `Name` is the final component of the virtual path passed by Total Commander,
  including an existing extension. It is available for files and folders and
  can be added to any custom-column view.

In a Total Commander custom-column view, the fields are available as:

- `[=<fs>.List position]`
- `[=<fs>.Source line]`
- `[=<fs>.Name]`

`List position` and `Source line` are empty for the plugin root, folders,
language entries, and list files themselves. Their values are cached by full
virtual path, so Total Commander may request them later or in a different order
without changing the reported position. `Name` is available for every non-root
virtual item.

The plugin also supplies a default WFX column view. Total Commander contributes
its fixed name and extension columns; the plugin view adds `List position` and
`Source line`. The separate plugin field `Name` is not added there to avoid a
duplicate name column. When entering the plugin, Total Commander switches to
the view automatically if **Use plugin columns** is enabled in Total
Commander's custom-column settings. The plugin does not modify `wincmd.ini`;
disabling that Total Commander option keeps the user's selected standard or
custom view.
Both ANSI and Unicode default-view callbacks are exported; current Windows
versions of Total Commander use the Unicode callback.

## Status And Error Codes

Result lines are shown like:

- `ProductName (value).NEW`
- `ProductName (value).UNCHANGED`
- `ProductName (CODE).ERROR` (localized extension text)

Meaning of common codes inside `(...)`:

- `403 - Forbidden`, `404 - Not Found`, `503 - Service Unavailable`, ...  
  HTTP status code returned by the server, followed by its standard reason phrase when known.
- `PARSE`  
  The configured markers could not be found/matched in the fetched page.
- `FILE - HTML response`  
  A file-check entry returned an HTML page instead of a downloadable file. The
  stored comparison value is not changed.
- `EMPTY`  
  Request finished, but no response body was returned.
- `ABORT`  
  User canceled while progress dialog was active.
- `WIN12002`  
  WinHTTP timeout (`ERROR_WINHTTP_TIMEOUT`).
- `WIN12007`  
  Name resolution failed (`ERROR_WINHTTP_NAME_NOT_RESOLVED`).
- `WIN12029`  
  Cannot connect (`ERROR_WINHTTP_CANNOT_CONNECT`).
- `WIN12030`  
  Connection error (`ERROR_WINHTTP_CONNECTION_ERROR`).
- `WIN12032`  
  Request retry required by WinHTTP (`ERROR_WINHTTP_RESEND_REQUEST`).
- `WIN12005`  
  Invalid URL (`ERROR_WINHTTP_INVALID_URL`).
- `ERROR`  
  Generic fallback when no more specific code is available.
- `403 - Forbidden - Cloudflare Protection - Chrome not found`  
  A Cloudflare protection page was detected, but Chrome is not installed or could not be located.
- `403 - Forbidden - Cloudflare Protection - Chrome still Cloudflare Protection`  
  Chrome loaded the page, but Cloudflare still returned a challenge or block page.
- `200 - OK - Anubis Challenge - Chrome background timeout`  
  Anubis was detected and the normal, off-screen Chrome fallback did not finish within the configured time.

Notes:

- `HTTP`/`EHTTPClient` style errors are from older implementations; current builds use WinHTTP and show HTTP status codes or `WINxxxxx`.
- The extension after the code is localized (for example `.ERROR` in English, translated labels in other language files).
- If `RequestLog=1`, technical details are written to `RequestLogFile` with timestamp, URL, status, and error code.

## Configuration (`versions.ini`)

The plugin reads configuration from `versions.ini` in the plugin directory.

Supported keys:

- `Language`  
  Language file without extension, e.g. `ver_English`. Files in `language\`
  take precedence; files beside the DLL remain supported for compatibility.
  The language menu merges both locations without duplicate names. An empty
  setting selects English.
- `UseLowerCase`  
  `1`/`0`, default `1`. Controls case-insensitive marker search behavior.
- `DontValidateCertificate`  
  `1`/`0`, default `0`. Disables SSL certificate validation when enabled.
- `MaxParallelRequests`  
  Integer, default `8`. Number of parallel fetch workers.
- `ConnectTimeout`  
  Integer milliseconds, default `5000`. Connection timeout per request.
- `RequestLog`  
  `1`/`0`, default `0`. Enables request logging.
- `RequestLogFile`  
  Log filename/path, default `versions_http.log`.  
  Relative paths are resolved against plugin directory.
- `ChromeFallback`  
  `1`/`0`, default `1`. Enables the automatic Chrome fallback for detected Cloudflare/Anubis pages.
- `UseChromeHeadless`  
  `1`/`0`, default `1`. Enables the first Chrome attempt with `--headless=new` and DOM output.
- `UseChromeHidden`  
  `1`/`0`, default `1`. Enables the fallback normal Chrome window, positioned off-screen, for challenges that need a full browser. Set this to `0` to prevent such a Chrome window from being started.
- `ChromePath`  
  Optional full path to `chrome.exe`. If empty, the plugin checks the Windows App Paths registry and the standard per-machine/per-user Chrome locations.
- `ChromeProfileDir`  
  Optional profile directory used only by the Chrome fallbacks. Default: `%LOCALAPPDATA%\VersionsWFX\ChromeProfile`.
- `ChromeTimeout`  
  Integer milliseconds, default `10000`, minimum `5000`. Timeout for each Chrome fallback; the headless attempt uses it additionally as JavaScript virtual-time budget.

The Chrome fallback is intentionally limited to detected protection pages. A regular HTTP error, a normal JavaScript page, or a page merely hosted behind Cloudflare continues to use WinHTTP only. `UseChromeHeadless` and `UseChromeHidden` can be set independently; with both set to `0`, detected protection pages remain WinHTTP errors with the detected protection noted.

## Quick View: GitHub release notes (Ctrl+Q)

In an active Versions list, the TC menu commands **View** (`cm_List`, 903) and
**Edit** (`cm_Edit`, 904) now follow the same actions as plain F3/F4: recheck the
selected entry, or open the native entry editor. This includes synchronous
context-menu commands, not just keyboard messages. Commands outside a Versions
list are forwarded unchanged. The host-window subclass is removed on window
destruction or DLL unload.

The normal TC Lister staging path `%TEMP%\_tc\filename` is also supported as a
preview-download fallback, in addition to Quick View's `_tc\$q` directory.
It returns release notes for matching GitHub entries or an empty file for other
entries, without turning an ordinary copy to other directories into a download.

For GitHub repository/release URLs, Ctrl+Q shows release notes as UTF-8 text
(Markdown source). The displayed version selects the release tag; explicit
`/releases/tag/...` URLs select that tag, and `/releases/latest` selects latest.
If a tag is not found directly, up to 100 releases are checked for a matching
tag/name (including an optional leading `v`). An unrelated latest release is
never substituted. This applies to github.com, not arbitrary github.io sites.
Other entries and list comments return an empty preview without a download
error. F3 remains the single-entry version check.
Quick View recognizes TC's `_tc\$q` destination, including Windows 8.3 paths.
Preview files use native Unicode filenames, including status suffixes with umlauts.
API requests run on a joined worker while the calling TC thread polls progress
and cancellation. Network/cache work uses a dedicated GitHub lock, never the
metadata lock, so custom-column queries remain responsive. Cancellation does
not cache a failed/partial preview. Every request worker/watchdog is joined
before the export returns; no background plugin work remains after cancellation.

Optionally put this comment **before** the affected entries in the list:

```text
; $githubkey=github_pat_YOUR_TOKEN
```

`githubkey` is a reserved, case-sensitive credential name, not a search-pattern
variable. Its last preceding definition applies to subsequent entries in that
list; `; $githubkey=` switches back to anonymous access. The token is sent only
to `https://api.github.com` with certificate validation and redirects disabled.
It is not included in request logs, previews, or F4 variable fields. The list
itself stores the token in plain text: keep it private and use minimal read-only
permissions. Public release notes work without a token; no new INI key is needed.

Successful previews are cached in memory for one hour per repository, release
and credential, until plugin unload. Repeated selection needs no API request.
Expired entries use conditional ETag requests where available. Normally the
first lookup takes one request, or two with tag fallback. Errors are briefly
cached; rate-limit reset and numeric Retry-After headers suspend further API
requests for the credential. Anonymous GitHub REST access normally allows
60 requests/hour/IP, authenticated access normally 5,000/hour/user; other apps
can share that budget. API errors appear inside the preview, not as failed TC
downloads. Five additional messages are localized in all seven language files.

## Build

The plugin registers its cleanup with FPC's `Dll_Process_Detach_Hook`. This
removes the TC message hook before DLL code is unmapped and releases the plugin
caches and synchronization objects. `tests/unload_cycle_test.pas` verifies 30
load/list/unload cycles, pumping messages after every unload to detect dangling
callbacks. Build it with the same Common Controls resource as `f4_flow_test`.

`tests/f4_flow_test.pas` is a WFX integration regression test. It loads the real
plugin and uses a small TC-message fixture to exercise listing, metadata lookup
with/without a leading backslash, F4 hook dispatch, the Properties callback,
and opening/cancelling the real editor. It creates only a temporary test list.
Compile its Common Controls manifest first using `fpcres -of res -I tests
tests/f4_flow_test.rc -o tests/f4_flow_test.res`, then build for the matching
architecture and pass the path to `Versions.wfx` or `Versions.wfx64`.

This project is configured for Free Pascal / Lazarus (`{$mode objfpc}`).

Example build command:

```powershell
lazbuild versions.lpi
```

Typical output binary:

- `Versions.wfx64`

## Original Credits

- Original plugin author: Fabio Chelly
- Later maintenance: ProgMan13

See `readme.txt` for original historical notes and legacy changelog.
