# Versions WFX Status

Last updated: 2026-11-08

## Fixed: stalled requests and cancellation (2026-11-08)

- Send/receive timeouts reduced from 20 to 10 seconds, independently of the
  existing ConnectTimeout setting. No INI keys/default meanings changed.
- Active synchronous WinHTTP requests have a short-lived cancellation watcher
  which closes the request handle. Ownership is transferred back after joining
  the watcher, preventing double-close/use after free. HTML and file reads,
  retry loops and queued Chrome attempts respect cancellation; initial cancel
  returns before starting the batch. A new editor Test resets stale cancel state.
- Quick View executes on a joined worker; TC progress callbacks remain on the
  caller thread. Dedicated GithubCS serializes cache/network work without holding
  ContentMetaCS. Cancellation interrupts the transport and does not cache errors.
- DevTools WebSocket watchdogs also poll cancellation instead of always waiting
  the full five seconds; aborted background Chrome skips graceful network close
  and uses the existing process/job cleanup immediately.
- Win32/Win64 production builds pass. Native regression hosts prove initial
  cancellation starts no request; stalled HTML headers/body and file HEAD/hash
  reads cancel in about 375-407 ms total with cancel requested after 350 ms,
  and no retries occur. Three configured 10-second receive timeouts end in
  WIN12002 in about 36 seconds overall on both targets (not a 10-second deadline).
- A separate test DLL changes only the GitHub transport endpoint at compile time
  (VERSIONS_TEST_TRANSPORT) for localhost fixtures. It verifies Quick View cancel
  plus concurrent metadata access under 200 ms; production builds contain no
  endpoint override. No installed plugin/config/list or archives were modified.
- The same local API fixture verifies successful UTF-8 release notes and a second
  preview served from cache without another HTTP request, on both architectures.
- Existing language/editor/variables/file/list/default-view tests, native editor
  HTTP/Quick-View flow and 30 unload cycles pass on both targets. Live TC/real
  Chrome cancellation remain manual checks, not inferred from localhost tests.
- No nonempty githubkey definition was found in installed .list files, so token
  validity could not be checked. A file location is needed; never print the token.

## Fixed: TC Quick View download error

- Corrected a second wrong assumption: the screenshot destination is
  `_tc\$q`, including the underscore. The previous `tc\$q` test was insufficient.
  A screenshot-shaped test first reproduced the failed WFX download.
- That test then exposed FS_FILE_WRITEERROR (4) for a filename containing
  UNVERÄNDERT. Replaced ANSI TFileStream filename conversion with native
  CreateFileW/WriteFile. Both WFX exports now return success with a real empty
  file at the exact Unicode destination; ordinary copy stays unchanged.
- Provider tests cover `_tc\$q`, traversal/nested-path rejection; integration
  covers actual FsGetFileW/FsGetFile, 8.3 parent paths and umlaut filenames.
- Win32/Win64 builds, provider tests and native editor/HTTP/Quick-View
  integration pass. The 8.3 integration tests ran outside the sandbox because
  its filesystem restrictions deny GetShortPathName (error 5). Live TC remains
  manual; installed plugins and TC configuration were not modified.

## Completed: GitHub Quick View

- Ctrl+Q returns matching GitHub release notes as UTF-8 Markdown text. Other
  entries return a successful empty preview; F3 and ordinary copy are unchanged.
- Optional list-local `; $githubkey=...` applies from its definition onwards.
  Reserved credentials are excluded from variable expansion/F4 fields, request
  logs and preview output. Authenticated transport is HTTPS api.github.com only,
  with certificate validation and redirects disabled.
- One-hour in-memory cache, conditional ETags, short error cache and per-key
  rate-limit/Retry-After pauses reduce requests. Tag lookup has a bounded release
  list fallback, never an unrelated latest-release fallback.
- All seven language files now contain 54 strings. README documents scope,
  token handling, cache lifetime and limits; no INI keys were added.
- Win32/Win64 builds and nine test programs per target pass: provider fixtures,
  language, editor, variables, file/list/default-view logic, 30 unload cycles,
  native editor/HTTP integration including real FsGetFileW empty Quick View
  and ordinary-copy regression checks. External GitHub service and live TC
  rendering remain manual checks. No installed plugin/config or archives changed.

## Fixed: unload crash

- Reproduced the pre-fix failure after FreeLibrary/message pumping
  (0xC000041D). The manual DLLEntryPoint cleanup was never registered with FPC;
  the WH_GETMESSAGE callback remained installed after its DLL was unmapped.
- Registered Dll_Process_Detach_Hook; cleanup removes and clears the hook and
  pending-key flags, then releases caches/objects and critical sections.
- Win32/Win64 builds pass. Each target passes 30 load/list/unload cycles with
  post-unload messages, plus editor/Test/HTTP integration followed by unloading.
  Existing editor, variable, file, list and default-view tests pass. Installed
  TC files/configuration were not changed; live TC confirmation remains manual.

## Completed

- Test dialog includes a two-line raw output: exact original start-to-end-marker
  match (inclusive, preserving case/newlines), or final HTTP headers for file
  checks. Missing complete matches and transport errors are explicit.
- Two new labels/messages are translated in all seven language files (49 lines).

- Fixed mixed ACP/UTF-8 encoding in Test results (e.g. UNVERÄNDERT).
  Test output is single-line and the dialog height is reduced accordingly.
- All seven languages from wfx_versions.zip are extended with 30 editor strings
  in language\, preserving the original 17 lines. Unicode loading supports
  UTF-8/UTF-16 and legacy CP1250/1251/1252; old files use English fallbacks.
  language\ is preferred, with DLL-adjacent compatibility and merged selection.

- F4 Test button asynchronously queries unsaved fields/variable definitions,
  displays the result inline, and leaves source/baselines/panel caches unchanged.
  The enlarged dialog uses individual single-line variable fields without bars.

- Native single-entry editor via plain F4 or result Properties, with active
  variable definitions, source-row/conflict checks and byte-preserving saves.
- Compact labeled-field entry form with complete source preview and separate
  variable definitions; native Save/Cancel tests pass on both architectures.
- F4 form centers on the TC owner window. Saving updates source state only,
  without an automatic panel reload or network checks; F3/Ctrl+R remain manual.
- F3/F4 dispatch through the selected item's Properties callback on TC 9+
  rather than starting a download and returning an abort to Lister.
- Shift+F4 opens the entire active list in Notepad. F3 repeats the selected
  result check only and refreshes TC from the in-memory display list.

- List-local `$name` text variables can be defined using `; $name=value`.
  Single-pass expansion preserves literal values and original source references
  when saving version/file-check updates; undefined names have explicit errors.

- `.list` files beside the plugin and recursively below `Lists` are supported.
- Parallel WinHTTP version checks, Cloudflare/Anubis detection, and optional
  Chrome fallback are implemented.
- File checks use `Last-Modified` when available and streaming SHA-256 otherwise.
- File-check results expose their server timestamp or stored SHA-256 baseline
  date through Total Commander's standard Date column.
- Pattern-based version results and other virtual list rows without a valid
  file-check timestamp leave the Date column empty.
- WFX custom columns `List position` and `Source line` expose visible order and
  physical `.list` line numbers.
- The WFX custom column `Name` exposes the virtual filename delivered by Total
  Commander, without its parent path.
- The WFX default view asks Total Commander to activate the plugin columns
  automatically when the plugin is entered. ANSI and Unicode callbacks are
  both exported.
- `;` comments remain hidden. `#`, `##`, and `###` comments appear without
  their markers as three non-executable indentation levels with a dedicated
  information icon.

## Verification

- Win32/Win64 HTTP fixture tests verify inclusive raw pattern ranges with case
  and line breaks and actual Last-Modified response headers for file tests,
  with no additional display-only request and no list write. All eight tests
  pass, including unload cycles and language/GUI checks.

- Win32/Win64 pass all eight tests, including seven-language/legacy encoding
  checks and the real HTTP editor test displaying German UNVERÄNDERT correctly.
  The result control is verified single-line with no visible scrollbars.

- Win32/Win64 editor tests cover unsaved field and variable testing, single-line
  variable styles, inline output, cancellation and unchanged source files.
- A local HTTP fixture exercises the real WFX Test callback on both targets:
  exactly one request from unsaved inputs, parsed inline result, no source write.

- Win32/Win64 native tests verify owner-centered positioning. WFX integration
  tests save without requesting a TC reread, then reopen with synchronized
  source text; all existing tests pass on both targets.

- F4 regression fixed: Properties callbacks omit the leading backslash that
  listing metadata previously retained. Metadata/source-row lookup now uses
  the same canonical key for both forms (also fixes F3's path-prefix check).
- Real WFX integration regression passes on Win32/Win64: listing, F4 hook,
  simulated TC Properties dispatch, trimmed-path lookup, native editor opening
  and cancellation. This does not replace live verification in installed TC.

- Entry editor tests pass for Win32 and Win64: source mapping, active variable,
  byte/line-ending preservation, UTF-16 LE, stale source and concurrent-change
  rejection, plus real native-window Save/Cancel tests on fixture files.
- F4 routing inside an installed Total Commander remains a manual check.
- F3/Shift+F4 key classification and single-row recheck persistence are covered
  on both targets; live TC key routing/network refresh remains a manual check.

- Win32 (`Versions.wfx`) and Win64 (`Versions.wfx64`) build successfully.
- File comparison/SHA-256 and visible-list comment/order logic tests pass for
  both Win32 and Win64.
- Variable expansion and source-preserving update tests pass for both targets,
  including the GitHub pattern, redefinitions, literal whitespace/quotes,
  unknown names, empty values, and list-local scope.
- Both binaries export all five required WFX content callbacks.
- Live visual verification inside Total Commander remains manual; no installed
  plugin files or Total Commander configuration were changed.
